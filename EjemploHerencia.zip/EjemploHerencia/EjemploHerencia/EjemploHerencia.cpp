// EjemploHerencia.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <iostream>
#include "Rectangulo.h"
#include "Cuadrado.h"
#include "conio.h"

using namespace std;

int main(void) {
   Rectangulo Rect;
 
   Rect.setWidth(5);
   Rect.setHeight(7);

   // Muestra el �rea de un rectangulo
   cout << "Total area: " << Rect.getArea() << endl;

   Cuadrado Cu;

   Cu.setWidth(5);
    // Muestra el �rea de un cuadrado
   cout << "Total area de cuadrado: " << Cu.getArea() << endl;

   getch();
   return 0;
}